import { useState, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Activity, Users, Bot, AlertTriangle, RefreshCw, Globe, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { auth, db } from "@/lib/firebase/config";
import { collection, query, where, onSnapshot, orderBy, limit, getDocs } from "firebase/firestore";
import { useNavigate } from "react-router-dom";

const COLORS = ["hsl(217, 91%, 60%)", "hsl(188, 85%, 53%)", "hsl(0, 84%, 60%)"];

interface TrafficData {
  id: string;
  timestamp: Date;
  type: 'human' | 'bot' | 'suspicious';
  ip: string;
  path: string;
  confidence: number;
  websiteId: string;
  userAgent: string;
}

interface Website {
  id: string;
  domain: string;
}

export default function LiveTraffic() {
  const [trafficData, setTrafficData] = useState<TrafficData[]>([]);
  const [websites, setWebsites] = useState<Website[]>([]);
  const [selectedWebsite, setSelectedWebsite] = useState<string>("all");
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    total: 0,
    humans: 0,
    bots: 0,
    suspicious: 0
  });
  
  const navigate = useNavigate();

  // Fetch websites
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) {
      navigate("/dashboard/login");
      return;
    }

    const fetchWebsites = async () => {
      const websitesRef = collection(db, "users", user.uid, "websites");
      const snapshot = await getDocs(websitesRef);
      const sites = snapshot.docs.map(doc => ({
        id: doc.id,
        domain: doc.data().domain
      }));
      setWebsites(sites);
    };

    fetchWebsites();
  }, [navigate]);

  // Real-time traffic listener
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    setLoading(true);

    // Build query based on selected website
    const trafficRef = collection(db, "users", user.uid, "traffic");
    let q;
    
    if (selectedWebsite !== "all") {
      q = query(
        trafficRef, 
        where("websiteId", "==", selectedWebsite),
        orderBy("timestamp", "desc"), 
        limit(100)
      );
    } else {
      q = query(trafficRef, orderBy("timestamp", "desc"), limit(100));
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        timestamp: doc.data().timestamp?.toDate() || new Date()
      })) as TrafficData[];
      
      setTrafficData(data);
      
      // Calculate stats
      const humans = data.filter(d => d.type === 'human').length;
      const bots = data.filter(d => d.type === 'bot').length;
      const suspicious = data.filter(d => d.type === 'suspicious').length;
      
      setStats({
        total: data.length,
        humans,
        bots,
        suspicious
      });
      
      setLoading(false);
    }, (error) => {
      console.error("Error fetching traffic:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [selectedWebsite]);

  // Prepare chart data
  const chartData = Array.from({ length: 12 }, (_, i) => {
    const hour = new Date();
    hour.setHours(hour.getHours() - (11 - i));
    
    const hourTraffic = trafficData.filter(d => {
      const dHour = d.timestamp.getHours();
      return dHour === hour.getHours();
    });
    
    return {
      time: `${hour.getHours()}:00`,
      human: hourTraffic.filter(d => d.type === 'human').length,
      bot: hourTraffic.filter(d => d.type === 'bot' || d.type === 'suspicious').length,
    };
  });

  // Prepare pie data
  const pieData = [
    { name: "Humans", value: stats.humans },
    { name: "Good Bots", value: 0 }, // You can differentiate if you have this data
    { name: "Bad Bots", value: stats.bots + stats.suspicious },
  ];

  // Get latest traffic for feed
  const latestTraffic = trafficData.slice(0, 20);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Live Traffic</h1>
        <div className="flex items-center gap-3">
          <select
            value={selectedWebsite}
            onChange={(e) => setSelectedWebsite(e.target.value)}
            className="bg-background/50 border border-border rounded-lg px-3 py-1.5 text-sm"
          >
            <option value="all">All Websites</option>
            {websites.map(site => (
              <option key={site.id} value={site.id}>{site.domain}</option>
            ))}
          </select>
          <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
            <RefreshCw className="h-4 w-4 mr-1" /> Refresh
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid sm:grid-cols-4 gap-4">
        <div className="glass rounded-xl p-5">
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
            <Activity className="h-4 w-4" /> Total Requests
          </div>
          <p className="text-3xl font-bold">{stats.total}</p>
          <p className="text-xs text-muted-foreground mt-1">Last 100 requests</p>
        </div>
        <div className="glass rounded-xl p-5">
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
            <Users className="h-4 w-4" /> Humans
          </div>
          <p className="text-3xl font-bold text-accent">{stats.humans}</p>
          <p className="text-xs text-muted-foreground mt-1">
            {stats.total > 0 ? ((stats.humans/stats.total)*100).toFixed(1) : 0}% of traffic
          </p>
        </div>
        <div className="glass rounded-xl p-5">
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
            <Bot className="h-4 w-4" /> Bots
          </div>
          <p className="text-3xl font-bold text-destructive">{stats.bots}</p>
          <p className="text-xs text-muted-foreground mt-1">
            {stats.total > 0 ? ((stats.bots/stats.total)*100).toFixed(1) : 0}% of traffic
          </p>
        </div>
        <div className="glass rounded-xl p-5">
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
            <AlertTriangle className="h-4 w-4" /> Suspicious
          </div>
          <p className="text-3xl font-bold text-yellow-500">{stats.suspicious}</p>
          <p className="text-xs text-muted-foreground mt-1">Needs review</p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass rounded-xl p-5">
          <h3 className="font-heading text-sm font-semibold mb-4">Human vs Bot Traffic (Last 12 Hours)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 16%)" />
              <XAxis dataKey="time" stroke="hsl(215, 20%, 55%)" fontSize={11} />
              <YAxis stroke="hsl(215, 20%, 55%)" fontSize={11} />
              <Tooltip 
                contentStyle={{ 
                  background: "hsl(222, 40%, 8%)", 
                  border: "1px solid hsl(222, 30%, 16%)", 
                  borderRadius: 8, 
                  fontSize: 12 
                }} 
              />
              <Bar dataKey="human" fill="hsl(217, 91%, 60%)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="bot" fill="hsl(0, 84%, 60%)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="glass rounded-xl p-5">
          <h3 className="font-heading text-sm font-semibold mb-4">Traffic Distribution</h3>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie 
                data={pieData} 
                cx="50%" 
                cy="50%" 
                innerRadius={60} 
                outerRadius={90} 
                dataKey="value" 
                stroke="none"
              >
                {pieData.map((_, i) => (
                  <Cell key={i} fill={COLORS[i]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  background: "hsl(222, 40%, 8%)", 
                  border: "1px solid hsl(222, 30%, 16%)", 
                  borderRadius: 8, 
                  fontSize: 12 
                }} 
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex justify-center gap-4 mt-2">
            {pieData.map((d, i) => (
              <div key={d.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className="w-2 h-2 rounded-full" style={{ background: COLORS[i] }} />
                {d.name} ({d.value})
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Live Feed */}
      <div className="glass rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading text-sm font-semibold">Live Traffic Feed</h3>
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-accent"></span>
            </span>
            <span className="text-xs text-muted-foreground">Live</span>
          </div>
        </div>
        
        <div className="space-y-2 max-h-[400px] overflow-y-auto">
          {latestTraffic.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Globe className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No traffic data yet</p>
              <p className="text-xs">Add your website script to start seeing traffic</p>
            </div>
          ) : (
            latestTraffic.map((item) => (
              <div key={item.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3 flex-1">
                  {item.type === 'human' ? (
                    <Users className="h-4 w-4 text-accent" />
                  ) : item.type === 'bot' ? (
                    <Bot className="h-4 w-4 text-destructive" />
                  ) : (
                    <AlertTriangle className="h-4 w-4 text-yellow-500" />
                  )}
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{item.ip || 'Unknown IP'}</span>
                      <span className="text-xs text-muted-foreground">•</span>
                      <span className="text-xs text-muted-foreground truncate max-w-[200px]">
                        {item.path || '/'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <Clock className="h-3 w-3 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">
                        {item.timestamp.toLocaleTimeString()}
                      </span>
                      {item.confidence > 0 && (
                        <>
                          <span className="text-xs text-muted-foreground">•</span>
                          <span className="text-xs text-muted-foreground">
                            Confidence: {item.confidence}%
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    item.type === 'human' ? 'bg-accent/10 text-accent' :
                    item.type === 'bot' ? 'bg-destructive/10 text-destructive' :
                    'bg-yellow-500/10 text-yellow-500'
                  }`}>
                    {item.type}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}