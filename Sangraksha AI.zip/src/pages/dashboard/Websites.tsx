import { useState, useEffect } from "react";
import { Globe, ShieldCheck, ExternalLink, X, Plus, ArrowLeft, BarChart3, Clock, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { auth, db } from "@/lib/firebase/config";
import { collection, addDoc, query, where, getDocs, doc, updateDoc, deleteDoc, onSnapshot } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";

interface Website {
  id: string;
  domain: string;
  status: "Active" | "Monitoring" | "Inactive";
  threats: number;
  added: string;
  scriptId: string;
  settings: {
    protectionLevel: "high" | "medium" | "low";
    blockThreshold: number;
    enableML: boolean;
  };
}

export default function Websites() {
  const [websites, setWebsites] = useState<Website[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newDomain, setNewDomain] = useState("");
  const [selectedSite, setSelectedSite] = useState<Website | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [scriptCopied, setScriptCopied] = useState(false);
  
  const { toast } = useToast();
  const navigate = useNavigate();

  // Fetch websites on component mount
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) {
      navigate("/dashboard/login");
      return;
    }

    // Real-time listener for websites
    const q = query(collection(db, "users", user.uid, "websites"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const websiteList: Website[] = [];
      snapshot.forEach((doc) => {
        websiteList.push({ id: doc.id, ...doc.data() } as Website);
      });
      setWebsites(websiteList);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching websites:", error);
      toast({
        title: "Error",
        description: "Failed to load websites",
        variant: "destructive",
      });
      setLoading(false);
    });

    return () => unsubscribe();
  }, [navigate, toast]);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDomain.trim()) return;

    const user = auth.currentUser;
    if (!user) {
      navigate("/dashboard/login");
      return;
    }

    setSaving(true);

    try {
      // Generate unique script ID
      const scriptId = `sang_${Math.random().toString(36).substring(2, 15)}_${Date.now()}`;

      // Add website to Firestore
      const websiteData = {
        domain: newDomain.trim(),
        status: "Monitoring",
        threats: 0,
        added: new Date().toISOString(),
        scriptId: scriptId,
        settings: {
          protectionLevel: "medium",
          blockThreshold: 85,
          enableML: true,
        },
      };

      await addDoc(collection(db, "users", user.uid, "websites"), websiteData);

      toast({
        title: "Success!",
        description: "Website added successfully",
      });

      setNewDomain("");
      setShowAdd(false);
    } catch (error) {
      console.error("Error adding website:", error);
      toast({
        title: "Error",
        description: "Failed to add website",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (websiteId: string) => {
    if (!confirm("Are you sure you want to remove this website?")) return;

    const user = auth.currentUser;
    if (!user) return;

    try {
      await deleteDoc(doc(db, "users", user.uid, "websites", websiteId));
      
      toast({
        title: "Success",
        description: "Website removed successfully",
      });

      if (selectedSite?.id === websiteId) {
        setSelectedSite(null);
      }
    } catch (error) {
      console.error("Error deleting website:", error);
      toast({
        title: "Error",
        description: "Failed to remove website",
        variant: "destructive",
      });
    }
  };

  const toggleProtection = async (website: Website) => {
    const user = auth.currentUser;
    if (!user) return;

    try {
      const newStatus = website.status === "Active" ? "Monitoring" : "Active";
      
      await updateDoc(doc(db, "users", user.uid, "websites", website.id), {
        status: newStatus,
      });

      toast({
        title: "Success",
        description: `Protection ${newStatus === "Active" ? "enabled" : "paused"}`,
      });
    } catch (error) {
      console.error("Error updating status:", error);
      toast({
        title: "Error",
        description: "Failed to update protection",
        variant: "destructive",
      });
    }
  };

  const copyScript = (scriptId: string) => {
    const script = `<!-- Sangrakshak AI Protection -->
<script>
  (function() {
    window._sangrakshak = {
      websiteId: "${scriptId}",
      endpoint: "https://api.sangrakshak.ai/v1/verify"
    };
    var s = document.createElement('script');
    s.src = "https://cdn.sangrakshak.ai/protect.min.js";
    s.async = true;
    document.head.appendChild(s);
  })();
</script>`;

    navigator.clipboard.writeText(script);
    setScriptCopied(true);
    setTimeout(() => setScriptCopied(false), 2000);
    
    toast({
      title: "Copied!",
      description: "Script copied to clipboard",
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Loading your websites...</p>
        </div>
      </div>
    );
  }

  if (selectedSite) {
    return (
      <div className="space-y-6">
        <button onClick={() => setSelectedSite(null)} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="h-4 w-4" /> Back to Websites
        </button>

        <div className="flex items-center gap-3 flex-wrap">
          <Globe className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold">{selectedSite.domain}</h1>
          <span className={`text-xs px-2 py-1 rounded-full font-medium ${
            selectedSite.status === "Active" ? "bg-accent/10 text-accent" : "bg-yellow-500/10 text-yellow-500"
          }`}>
            {selectedSite.status}
          </span>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => toggleProtection(selectedSite)}
            className="ml-auto"
          >
            {selectedSite.status === "Active" ? "Pause Protection" : "Enable Protection"}
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid sm:grid-cols-3 gap-4">
          <div className="glass rounded-xl p-5">
            <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
              <ShieldCheck className="h-4 w-4" /> Threats Blocked
            </div>
            <p className="text-3xl font-bold font-heading">{selectedSite.threats.toLocaleString()}</p>
          </div>
          <div className="glass rounded-xl p-5">
            <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
              <Clock className="h-4 w-4" /> Added On
            </div>
            <p className="text-lg font-bold font-heading">{new Date(selectedSite.added).toLocaleDateString()}</p>
          </div>
          <div className="glass rounded-xl p-5">
            <div className="flex items-center gap-2 text-muted-foreground text-sm mb-2">
              <BarChart3 className="h-4 w-4" /> Protection Level
            </div>
            <p className="text-lg font-bold font-heading text-accent capitalize">{selectedSite.settings.protectionLevel}</p>
          </div>
        </div>

        {/* Integration Script */}
        <div className="glass rounded-xl p-5 space-y-4">
          <h3 className="font-heading text-sm font-semibold">Integration Script</h3>
          <p className="text-sm text-muted-foreground">
            Add this script to your website's <code className="bg-muted px-1 py-0.5 rounded">&lt;head&gt;</code> section
          </p>
          <div className="bg-muted/30 p-4 rounded-lg font-mono text-xs overflow-x-auto">
            {`<!-- Sangrakshak AI Protection -->
<script>
  window._sangrakshak = {
    websiteId: "${selectedSite.scriptId}",
    endpoint: "https://api.sangrakshak.ai/v1/verify"
  };
</script>
<script src="https://cdn.sangrakshak.ai/protect.min.js" async></script>`}
          </div>
          <div className="flex gap-2">
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => copyScript(selectedSite.scriptId)}
            >
              {scriptCopied ? "Copied!" : "Copy Script"}
            </Button>
            <Button 
              size="sm" 
              variant="destructive"
              onClick={() => handleDelete(selectedSite.id)}
            >
              Remove Website
            </Button>
          </div>
        </div>

        {/* Recent Threat Log */}
        <div className="glass rounded-xl p-5 space-y-4">
          <h3 className="font-heading text-sm font-semibold">Recent Threat Log</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-muted-foreground border-b border-border">
                  <th className="pb-2 pr-4">Time</th>
                  <th className="pb-2 pr-4">IP Address</th>
                  <th className="pb-2 pr-4">Type</th>
                  <th className="pb-2">Status</th>
                </tr>
              </thead>
              <tbody className="text-muted-foreground">
                {[
                  { time: "2 min ago", ip: "192.168.1.45", type: "Scraper Bot", status: "Blocked" },
                  { time: "8 min ago", ip: "10.0.0.12", type: "Credential Stuffing", status: "Blocked" },
                  { time: "15 min ago", ip: "172.16.0.89", type: "DDoS Attempt", status: "Blocked" },
                ].map((log, i) => (
                  <tr key={i} className="border-b border-border/50">
                    <td className="py-2 pr-4">{log.time}</td>
                    <td className="py-2 pr-4 font-mono text-xs">{log.ip}</td>
                    <td className="py-2 pr-4">{log.type}</td>
                    <td className="py-2"><span className="text-xs px-2 py-0.5 rounded-full bg-destructive/10 text-destructive">{log.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">My Websites</h1>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90" size="sm" onClick={() => setShowAdd(true)}>
          <Plus className="h-4 w-4 mr-1" /> Add Website
        </Button>
      </div>

      {/* Add Website Modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
          <div className="glass rounded-xl p-6 w-full max-w-md relative">
            <button onClick={() => setShowAdd(false)} className="absolute top-4 right-4 text-muted-foreground hover:text-foreground">
              <X className="h-5 w-5" />
            </button>
            <h2 className="text-xl font-bold mb-4">Add New Website</h2>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">Domain</label>
                <Input
                  placeholder="e.g. example.com"
                  value={newDomain}
                  onChange={(e) => setNewDomain(e.target.value)}
                  required
                  disabled={saving}
                  className="bg-background/50 border-border"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                After adding, you'll get a unique script to paste into your website.
              </p>
              <div className="flex gap-3 justify-end">
                <Button type="button" variant="ghost" size="sm" onClick={() => setShowAdd(false)} disabled={saving}>
                  Cancel
                </Button>
                <Button type="submit" size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" disabled={saving}>
                  {saving ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Adding...
                    </>
                  ) : (
                    "Add Website"
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Websites Grid */}
      {websites.length === 0 ? (
        <div className="glass rounded-xl p-12 text-center">
          <Globe className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No websites added yet</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Add your first website to start protecting it from bots.
          </p>
          <Button onClick={() => setShowAdd(true)} className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Plus className="h-4 w-4 mr-1" /> Add Your First Website
          </Button>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {websites.map((w) => (
            <div key={w.id} className="glass rounded-xl p-5">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-primary" />
                  <span className="font-semibold">{w.domain}</span>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                  w.status === "Active" ? "bg-accent/10 text-accent" : "bg-yellow-500/10 text-yellow-500"
                }`}>
                  {w.status}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <ShieldCheck className="h-3.5 w-3.5" />
                  {w.threats.toLocaleString()} threats blocked
                </div>
                <span>Added {new Date(w.added).toLocaleDateString()}</span>
              </div>
              <div className="flex gap-2 mt-3">
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-primary hover:text-primary/80 p-0 h-auto"
                  onClick={() => setSelectedSite(w)}
                >
                  <ExternalLink className="h-3.5 w-3.5 mr-1" /> Details
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-muted-foreground hover:text-foreground p-0 h-auto ml-auto"
                  onClick={() => copyScript(w.scriptId)}
                >
                  Copy Script
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}